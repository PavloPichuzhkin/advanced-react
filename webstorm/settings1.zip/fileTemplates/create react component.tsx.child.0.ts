export { ${NAME} } from './${NAME}';
